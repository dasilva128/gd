# app/core/models.py

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import Integer, String, BigInteger, DateTime, ForeignKey, Text, Index, UniqueConstraint
from datetime import datetime, timedelta, timezone
from app.core.db import Base

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tg_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    first_name: Mapped[str | None] = mapped_column(String(128))
    last_name: Mapped[str | None] = mapped_column(String(128))
    username: Mapped[str | None] = mapped_column(String(64))
    lang: Mapped[str | None] = mapped_column(String(16))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))

    downloads: Mapped[list["Download"]] = relationship(back_populates="user", cascade="all,delete-orphan")
    events: Mapped[list["Event"]] = relationship(back_populates="user", cascade="all,delete-orphan")

class Event(Base):
    __tablename__ = "events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    ts: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    type: Mapped[str] = mapped_column(String(32))
    payload: Mapped[str | None] = mapped_column(Text)

    user: Mapped["User"] = relationship(back_populates="events")

class Download(Base):
    __tablename__ = "downloads"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    ts: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))
    source: Mapped[str] = mapped_column(String(16))  # تیک‌تاک|شورتز|ریلز
    url: Mapped[str] = mapped_column(Text)
    title: Mapped[str | None] = mapped_column(Text)
    duration_sec: Mapped[int | None] = mapped_column(Integer)
    file_size: Mapped[int | None] = mapped_column(Integer)
    ext: Mapped[str | None] = mapped_column(String(8))

    user: Mapped["User"] = relationship(back_populates="downloads")

class MediaCache(Base):
    __tablename__ = "media_cache"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    source: Mapped[str] = mapped_column(String(16), index=True)
    extractor: Mapped[str] = mapped_column(String(32), index=True)
    media_id: Mapped[str] = mapped_column(String(128))
    kind: Mapped[str] = mapped_column(String(16))
    tg_file_id: Mapped[str] = mapped_column(String(512))  # برای ارسال
    tg_file_unique_id: Mapped[str] = mapped_column(String(256))  # ددوپلیکیشن پایدار
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)

    __table_args__ = (
        UniqueConstraint("extractor", "media_id", "kind", name="uq_media_cache_key"),
        Index("ix_media_cache_lookup", "extractor", "media_id", "kind"),
    )

class Token(Base):
    __tablename__ = "tokens"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ns: Mapped[str] = mapped_column(String(32), index=True)  # فضای نام (مانند "dl")
    token: Mapped[str] = mapped_column(String(64), unique=True)  # شناسه کوتاه
    value: Mapped[str] = mapped_column(Text)  # ذخیره URL/داده‌ها
    expires_at: Mapped[datetime] = mapped_column(DateTime, index=True)

Index("ix_tokens_ns_token", Token.ns, Token.token, unique=True)